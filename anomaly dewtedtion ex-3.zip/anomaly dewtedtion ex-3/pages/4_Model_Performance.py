"""FinGuard AI - Model Performance & Evaluation Studio.

Out-of-sample model evaluation, confusion matrix heatmaps, Precision-Recall curves,
threshold trade-off sweeps, baseline comparisons, and model registry management.
"""

import sys
from pathlib import Path
import pandas as pd
import numpy as np
import streamlit as st

BASE_DIR = Path(__file__).resolve().parent.parent
if str(BASE_DIR) not in sys.path:
    sys.path.insert(0, str(BASE_DIR))

from config.settings import settings
from components.theme import configure_page
from components.cards import render_header, render_metric_card
from components.charts import (
    create_confusion_matrix_chart,
    create_precision_recall_curve_chart,
    create_threshold_tradeoff_chart
)
from src.features.preprocessor import split_transaction_data, TransactionPreprocessor
from src.models.isolation_forest import IsolationForestAnomalyModel
from src.models.autoencoder import AutoencoderAnomalyModel
from src.models.evaluation import (
    evaluate_anomaly_model,
    evaluate_threshold_grid,
    find_optimal_threshold,
    evaluate_baseline_comparisons,
    ModelEvaluationReport
)
from src.models.registry import get_active_model, set_active_model, list_available_models
from src.data.loader import check_benchmark_dataset_exists, load_csv_dataset
from src.data.demo_generator import generate_synthetic_demo_data

configure_page(page_title="Model Performance")

# Session State Setup
if "dataset" not in st.session_state or st.session_state.dataset is None:
    bench_exists, bench_path = check_benchmark_dataset_exists()
    if bench_exists:
        try:
            df_bench, rep = load_csv_dataset(bench_path)
            st.session_state.dataset = df_bench
            st.session_state.data_source_type = "BENCHMARK"
        except Exception:
            pass

render_header(
    title="Model Performance & Evaluation",
    subtitle="Mathematical validation metrics, Precision-Recall optimization, confusion matrices, and baseline comparisons.",
    badge_text="METRICS VERIFIED",
    badge_type="high"
)

if "dataset" not in st.session_state or st.session_state.dataset is None:
    st.info("No dataset loaded. Please generate synthetic demo data or load the benchmark dataset from Executive Overview.")
    if st.button("Generate Synthetic Demo Batch", type="primary"):
        demo_df = generate_synthetic_demo_data(n_samples=settings.DEMO_SAMPLES_COUNT, save_to_file=True)
        st.session_state.dataset = demo_df
        st.session_state.data_source_type = "DEMO"
        st.rerun()
    st.stop()

df = st.session_state.dataset
active_model = get_active_model()

# Model Selector & Switcher
st.markdown("### Active Model Deployment")
col_reg1, col_reg2 = st.columns([2, 1])
with col_reg1:
    available_models = list_available_models()
    model_opts = {m.model_name: m.model_name for m in available_models} if available_models else {"Isolation Forest (Default)": "Isolation Forest"}
    chosen_m_name = st.selectbox("Select Active Production Engine", options=list(model_opts.keys()))
with col_reg2:
    st.markdown("<div style='height: 1.8rem;'></div>", unsafe_allow_html=True)
    if st.button("Set as Active Engine", type="primary"):
        matching = [m for m in available_models if m.model_name == chosen_m_name]
        if matching:
            set_active_model(matching[0])
            st.success(f"Switched active model to: {chosen_m_name}")
            st.rerun()

# Out-of-Sample Evaluation Execution
st.markdown("---")
st.markdown("### Out-of-Sample Holdout Evaluation")

if settings.TARGET_COL not in df.columns:
    st.warning("The current dataset lacks ground-truth 'Class' labels for supervised metric calculation. Metrics require benchmark labels.")
    st.stop()

# Cache train/test split to avoid recomputing
@st.cache_data
def get_cached_split(data_len: int, target_sum: int):
    return split_transaction_data(df, target_col="Class", test_size=0.20, random_state=42)

X_train, X_test, y_train, y_test = get_cached_split(len(df), int(df[settings.TARGET_COL].sum()))

# Ensure model is trained
if active_model and not active_model.is_trained:
    with st.spinner(f"Fitting {active_model.model_name} on training partition (N={len(X_train):,})..."):
        active_model.fit(X_train)

# Slider for decision threshold
eval_cutoff = st.slider(
    "Evaluation Decision Threshold",
    min_value=0.10,
    max_value=0.95,
    value=float(active_model.threshold if active_model else 0.65),
    step=0.05
)

# Run Evaluation
report: ModelEvaluationReport = evaluate_anomaly_model(active_model, X_test, y_test, threshold=eval_cutoff)

# Metric KPI Row
m_c1, m_c2, m_c3, m_c4, m_c5 = st.columns(5)
with m_c1:
    st.metric("Precision", f"{report.precision:.2%}")
with m_c2:
    st.metric("Recall", f"{report.recall:.2%}")
with m_c3:
    st.metric("F1-Score", f"{report.f1_score:.4f}")
with m_c4:
    st.metric("PR-AUC", f"{report.pr_auc:.4f}")
with m_c5:
    st.metric("ROC-AUC", f"{report.roc_auc:.4f}")

st.markdown("<div style='height: 1rem;'></div>", unsafe_allow_html=True)

# Confusion Matrix and Tradeoff Charts
ch_col1, ch_col2 = st.columns([1, 1.4])
with ch_col1:
    st.markdown("#### Confusion Matrix")
    cm_payload = {
        "true_positives": report.true_positives,
        "false_positives": report.false_positives,
        "true_negatives": report.true_negatives,
        "false_negatives": report.false_negatives
    }
    st.plotly_chart(
        create_confusion_matrix_chart(cm_payload, threshold=eval_cutoff),
        use_container_width=True
    )

with ch_col2:
    st.markdown("#### Threshold Sensitivity Sweep")
    grid_df = evaluate_threshold_grid(active_model, X_test, y_test)
    st.plotly_chart(create_threshold_tradeoff_chart(grid_df), use_container_width=True)

# Precision-Recall Curve
st.markdown("#### Precision-Recall Operating Curve")
test_scores = active_model.predict_score(X_test)
st.plotly_chart(
    create_precision_recall_curve_chart(y_test.values, test_scores, current_threshold=eval_cutoff),
    use_container_width=True
)

# Baseline Comparisons
st.markdown("---")
st.markdown("### Comparative Baseline Models")
baselines = evaluate_baseline_comparisons(X_test, y_test)

b_rows = []
# Active Model
b_rows.append({
    "Model Architecture": f"FinGuard Active ({active_model.model_name})",
    "Precision": f"{report.precision:.2%}",
    "Recall": f"{report.recall:.2%}",
    "F1-Score": f"{report.f1_score:.4f}",
    "False Positives": report.false_positives,
    "True Positives": report.true_positives,
    "Methodology": "Unsupervised high-dimensional tree isolation / neural bottleneck"
})
# Baselines
for b_name, b_val in baselines.items():
    b_rows.append({
        "Model Architecture": b_name,
        "Precision": f"{b_val['precision']:.2%}",
        "Recall": f"{b_val['recall']:.2%}",
        "F1-Score": f"{b_val['f1']:.4f}",
        "False Positives": b_val["false_positives"],
        "True Positives": b_val["true_positives"],
        "Methodology": b_val["description"]
    })

st.dataframe(pd.DataFrame(b_rows), use_container_width=True)
