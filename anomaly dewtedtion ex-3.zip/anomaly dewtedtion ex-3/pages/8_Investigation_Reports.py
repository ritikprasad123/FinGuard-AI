"""FinGuard AI - Investigation Reports Hub.

Generates audit-compliant compliance investigation reports, batch triage summaries,
and data quality certificates in exportable Markdown and text formats.
"""

import sys
from pathlib import Path
from datetime import datetime, timezone
import pandas as pd
import streamlit as st

BASE_DIR = Path(__file__).resolve().parent.parent
if str(BASE_DIR) not in sys.path:
    sys.path.insert(0, str(BASE_DIR))

from config.settings import settings
from components.theme import configure_page
from components.cards import render_header
from src.investigation.case_manager import CaseManager
from src.investigation.alert_feed import generate_alerts_from_dataset
from src.models.registry import get_active_model
from src.reports.investigation_report import (
    generate_case_investigation_report,
    generate_alert_triage_batch_report
)
try:
    from src.reports.quality_report import generate_markdown_quality_report
except ImportError:
    from src.reports.quality_report import format_quality_markdown_report as generate_markdown_quality_report
from src.data.validator import validate_transaction_data

configure_page(page_title="Investigation Reports")
case_manager = CaseManager()

render_header(
    title="Compliance & Investigation Reports",
    subtitle="Generate exportable audit-ready memoranda, batch triage reports, and pipeline quality certificates.",
    badge_text="REPORTS DESK",
    badge_type="high"
)

# Tabbed Interface for 3 Report Types
tab_case_rep, tab_triage_rep, tab_quality_rep = st.tabs([
    "Case Investigation Dossier",
    "Batch Alert Triage Report",
    "Data Quality Audit Certificate"
])

# -------------------------------------------------------------
# TAB 1: CASE INVESTIGATION DOSSIER
# -------------------------------------------------------------
with tab_case_rep:
    st.markdown("### Formal Case Investigation Dossier")
    cases = case_manager.list_cases()

    if not cases:
        st.info("No active cases in SQLite database. Create a case from 'Case Management' or 'Transaction Monitoring'.")
    else:
        case_map = {f"{c['case_id']} — {c['title']} ({c['status']})": c['case_id'] for c in cases}
        chosen_label = st.selectbox("Select Case File for Report Generation", options=list(case_map.keys()))
        chosen_id = case_map[chosen_label]

        case_obj = case_manager.get_case(chosen_id)
        if case_obj:
            dataset_ctx = st.session_state.get("dataset")
            case_md = generate_case_investigation_report(case_obj, transactions_df=dataset_ctx)

            st.download_button(
                label=f"Download Official Case Dossier ({chosen_id}.md)",
                data=case_md,
                file_name=f"{chosen_id}_investigation_dossier.md",
                mime="text/markdown",
                type="primary"
            )

            st.markdown("#### Document Preview")
            st.markdown(
                f"<div style='background: var(--bg-card); padding: 1.5rem; border-radius: 6px; border: 1px solid var(--border-color); font-size: 0.88rem; line-height: 1.6;'>",
                unsafe_allow_html=True
            )
            st.markdown(case_md)
            st.markdown("</div>", unsafe_allow_html=True)

# -------------------------------------------------------------
# TAB 2: BATCH ALERT TRIAGE REPORT
# -------------------------------------------------------------
with tab_triage_rep:
    st.markdown("### Batch Alert Triage Summary Report")
    df_ctx = st.session_state.get("dataset")

    if df_ctx is None:
        st.info("No dataset loaded in surveillance session.")
    else:
        active_model = get_active_model()
        cutoff_val = active_model.threshold if (active_model and active_model.is_trained) else 0.65
        model_name_str = active_model.model_name if active_model else "Heuristic Engine"

        alerts = generate_alerts_from_dataset(df_ctx, model=active_model, threshold=cutoff_val, max_alerts=100)
        triage_md = generate_alert_triage_batch_report(alerts, model_name=model_name_str, threshold=cutoff_val)

        st.download_button(
            label="Download Batch Triage Report (.md)",
            data=triage_md,
            file_name=f"finguard_alert_triage_report_{datetime.now(timezone.utc).strftime('%Y%m%d')}.md",
            mime="text/markdown",
            type="primary"
        )

        st.markdown("#### Document Preview")
        st.markdown(
            f"<div style='background: var(--bg-card); padding: 1.5rem; border-radius: 6px; border: 1px solid var(--border-color); font-size: 0.88rem; line-height: 1.6;'>",
            unsafe_allow_html=True
        )
        st.markdown(triage_md)
        st.markdown("</div>", unsafe_allow_html=True)

# -------------------------------------------------------------
# TAB 3: DATA QUALITY AUDIT CERTIFICATE
# -------------------------------------------------------------
with tab_quality_rep:
    st.markdown("### Data Quality & Pipeline Audit Certificate")
    df_ctx = st.session_state.get("dataset")

    if df_ctx is None:
        st.info("No dataset loaded in surveillance session.")
    else:
        quality_rep = validate_transaction_data(df_ctx)
        cert_md = generate_markdown_quality_report(quality_rep)

        st.download_button(
            label="Download Data Quality Certificate (.md)",
            data=cert_md,
            file_name=f"finguard_quality_audit_certificate_{datetime.now(timezone.utc).strftime('%Y%m%d')}.md",
            mime="text/markdown",
            type="primary"
        )

        st.markdown("#### Document Preview")
        st.markdown(
            f"<div style='background: var(--bg-card); padding: 1.5rem; border-radius: 6px; border: 1px solid var(--border-color); font-size: 0.88rem; line-height: 1.6;'>",
            unsafe_allow_html=True
        )
        st.markdown(cert_md)
        st.markdown("</div>", unsafe_allow_html=True)
