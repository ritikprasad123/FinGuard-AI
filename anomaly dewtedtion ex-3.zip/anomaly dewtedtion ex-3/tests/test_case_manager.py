"""Unit tests for SQLite Case Management System."""

import pytest
from pathlib import Path
from src.investigation.case_manager import CaseManager


@pytest.fixture
def temp_case_manager(tmp_path):
    db_file = tmp_path / "test_cases.db"
    return CaseManager(db_path=db_file)


def test_case_creation_and_retrieval(temp_case_manager):
    cid = temp_case_manager.create_case(
        title="Unauthorized overseas card testing",
        priority="CRITICAL",
        assigned_analyst="Analyst-42",
        linked_transactions=["TXN-1001", "TXN-1002"],
        summary="High-velocity micro charges observed across foreign gateways.",
        initial_note="Opening case upon automated surveillance alert."
    )

    assert cid.startswith("CASE-")
    case = temp_case_manager.get_case(cid)
    assert case is not None
    assert case["title"] == "Unauthorized overseas card testing"
    assert case["priority"] == "CRITICAL"
    assert case["status"] == "OPEN"
    assert case["assigned_analyst"] == "Analyst-42"
    assert "TXN-1001" in case["linked_transactions"]
    assert "TXN-1002" in case["linked_transactions"]
    assert len(case["notes"]) == 1
    assert case["notes"][0]["content"] == "Opening case upon automated surveillance alert."
    assert len(case["history"]) >= 1


def test_case_status_transition_and_audit_history(temp_case_manager):
    cid = temp_case_manager.create_case(title="Suspicious volume spike", priority="HIGH")

    # Update status to INVESTIGATING
    res = temp_case_manager.update_case_status(
        cid, "INVESTIGATING", author="Officer-Smith", reason="Contacting issuing bank"
    )
    assert res is True

    case = temp_case_manager.get_case(cid)
    assert case["status"] == "INVESTIGATING"

    # Verify audit history
    actions = [h["action"] for h in case["history"]]
    assert "STATUS_CHANGE" in actions

    # Reject invalid status
    with pytest.raises(ValueError, match="Invalid status"):
        temp_case_manager.update_case_status(cid, "INVALID_STATUS_CODE")


def test_case_notes_logging(temp_case_manager):
    cid = temp_case_manager.create_case(title="Test notes logging")

    nid1 = temp_case_manager.add_case_note(cid, author="Analyst-A", content="First observation: V14 is -8.5.")
    nid2 = temp_case_manager.add_case_note(cid, author="Analyst-B", content="Second observation: IP mismatch.")

    assert nid1 > 0 and nid2 > nid1

    case = temp_case_manager.get_case(cid)
    assert len(case["notes"]) == 2
    assert case["notes"][0]["author"] == "Analyst-A"
    assert case["notes"][1]["author"] == "Analyst-B"

    # Reject empty note
    with pytest.raises(ValueError, match="cannot be empty"):
        temp_case_manager.add_case_note(cid, author="Analyst-A", content="   ")


def test_link_transaction_and_lookup(temp_case_manager):
    cid = temp_case_manager.create_case(title="Multi-transaction cluster")
    temp_case_manager.link_transaction_to_case(cid, "TXN-ALPHA-99")
    temp_case_manager.link_transaction_to_case(cid, "TXN-BETA-88")

    matches_alpha = temp_case_manager.find_cases_by_transaction("TXN-ALPHA-99")
    assert len(matches_alpha) == 1
    assert matches_alpha[0]["case_id"] == cid

    matches_none = temp_case_manager.find_cases_by_transaction("NON-EXISTENT-TXN")
    assert len(matches_none) == 0


def test_list_cases_filtering_and_metrics(temp_case_manager):
    temp_case_manager.create_case(title="Critical Case", priority="CRITICAL")
    c2 = temp_case_manager.create_case(title="High Case", priority="HIGH")
    temp_case_manager.update_case_status(c2, "ESCALATED_AML")

    all_cases = temp_case_manager.list_cases()
    assert len(all_cases) == 2

    crit_cases = temp_case_manager.list_cases(priority="CRITICAL")
    assert len(crit_cases) == 1
    assert crit_cases[0]["priority"] == "CRITICAL"

    aml_cases = temp_case_manager.list_cases(status="ESCALATED_AML")
    assert len(aml_cases) == 1
    assert aml_cases[0]["status"] == "ESCALATED_AML"

    metrics = temp_case_manager.get_case_metrics()
    assert metrics["total_cases"] == 2
    assert metrics["critical_priority"] == 1
    assert metrics["escalated_aml"] == 1
